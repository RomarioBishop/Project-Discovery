# Project-Discovery
This is a member management system for Project Discovery Barbados, this will help with managing member subscriptions and member information like community service
